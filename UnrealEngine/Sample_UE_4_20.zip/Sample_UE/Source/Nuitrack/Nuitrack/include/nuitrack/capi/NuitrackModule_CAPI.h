#ifndef NUITRACK_NUITRACKMODULE_CAPI_H_
#define NUITRACK_NUITRACKMODULE_CAPI_H_

#include "nuitrack/modules/Module.h"

#endif /* NUITRACK_NUITRACKMODULE_CAPI_H_ */
