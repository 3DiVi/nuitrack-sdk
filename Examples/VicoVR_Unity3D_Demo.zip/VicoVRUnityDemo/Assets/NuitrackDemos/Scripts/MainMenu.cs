﻿using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;

public class MainMenu : MonoBehaviour 
{
  public void LoadDepthAndUserTrackerScene()
  {
    SceneManager.LoadScene(1);
    //Application.LoadLevel(1); pre 5.3
  }

  public void LoadSkeletonScene()
  {
    SceneManager.LoadScene(2);
    //Application.LoadLevel(2); pre 5.3
  }

  public void LoadAllModulesScene()
  {
    SceneManager.LoadScene(3);
    //Application.LoadLevel(3); pre 5.3
  }

  public void LoadPointCloud()
  {
    SceneManager.LoadScene(4);
  }
}
