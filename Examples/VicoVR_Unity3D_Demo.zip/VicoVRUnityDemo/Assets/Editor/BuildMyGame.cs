﻿using System;
using System.Linq;
using UnityEditor;

public class BuildMyGame
{

    public static void BuildAndroid()
    {
        Build(BuildTarget.Android);
    }

    public static void Build(BuildTarget target)
    {
        var scenes = new[] { "Assets/NuitrackDemos/allModulesScene.unity" }; //Список сцен
        //Ключ
        PlayerSettings.Android.keystoreName = "C:\\KeyStore\\my-release-key.keystore";
        PlayerSettings.Android.keystorePass = "q2w3e4r";
        PlayerSettings.Android.keyaliasName = "main_key";
        PlayerSettings.Android.keyaliasPass = "q2w3e4r";
        BuildPipeline.BuildPlayer(scenes.ToArray(), Environment.GetCommandLineArgs().Last(), target, BuildOptions.None); //настройки сборки
    }
}