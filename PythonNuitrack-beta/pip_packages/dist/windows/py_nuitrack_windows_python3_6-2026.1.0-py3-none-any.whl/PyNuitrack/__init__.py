import os,sys
if ".".join(str(x) for x in sys.version_info[:2]) not in ("3.6","3.7") and sys.platform != "linux":
	os.add_dll_directory(os.getenv('NUITRACK_HOME') + '/bin')